from django.contrib import admin
from .models import Recruiter, Pcell
# Register your models here.
admin.site.register(Recruiter)
admin.site.register(Pcell)
