from django.contrib import admin
from .models import RentIn

admin.site.register(RentIn)